from django.contrib import admin
from.models import Commande
# Register your models here.

admin.site.register(Commande)